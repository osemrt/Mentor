package model;

public class SpinnerItem {

    private String title;

    public SpinnerItem(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
